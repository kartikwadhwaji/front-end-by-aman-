# Night Light Companion

An AI-powered emotional support companion app designed to help users manage their emotional well-being. This project helps college students and users experiencing loneliness find a gentle, non-judgmental space to process their feelings.

## Features

- **Emotional Baseline**: Track your current mood and emotional drift.
- **Guided Breathing**: Simple breathing exercises to regain calm.
- **Journaling**: Private space to write down thoughts.
- **AI Chat**: A gentle companion to talk to.
- **Wellness Insights**: Data-driven insights into your emotional patterns.

## Tech Stack

- **Framework**: React 18 + Vite
- **Language**: TypeScript
- **Styling**: Tailwind CSS + Shadcn UI
- **Animation**: Framer Motion
- **State Management**: React Query + React Context

## Getting Started

### Prerequisites

- Node.js (v18+ recommended)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```

## Building for Production

To create a production build:

```bash
npm run build
```

## Contributing

This project is independently built and maintained. Pull requests are welcome.
