import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, Sparkles, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Journal Page
 * 
 * Simple journaling feature with prompts.
 * Helps users reflect on their feelings.
 * 
 * In real app: Journal entries would be saved to backend.
 */

const journalPrompts = [
  "What's one thing that made you smile today?",
  "What are you grateful for right now?",
  "If you could tell someone how you feel, what would you say?",
  "What's something you're looking forward to?",
  "What would make tomorrow a little better?",
  "What's something kind you did for yourself today?",
  "What's on your mind right now?",
  "What's one small thing you accomplished today?",
];

interface JournalProps {
  onBack: () => void;
}

export function Journal({ onBack }: JournalProps) {
  const [promptIndex, setPromptIndex] = useState(
    Math.floor(Math.random() * journalPrompts.length)
  );
  const [entry, setEntry] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  const currentPrompt = journalPrompts[promptIndex];

  const handleNewPrompt = () => {
    let newIndex = Math.floor(Math.random() * journalPrompts.length);
    while (newIndex === promptIndex && journalPrompts.length > 1) {
      newIndex = Math.floor(Math.random() * journalPrompts.length);
    }
    setPromptIndex(newIndex);
    setEntry('');
    setIsSaved(false);
  };

  const handleSave = () => {
    if (entry.trim()) {
      // In real app: Save to backend
      setIsSaved(true);
      setTimeout(() => setIsSaved(false), 2000);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-4 p-4 border-b border-border/50"
      >
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-amber-500" />
          <h1 className="font-semibold text-foreground">Journal</h1>
        </div>
      </motion.header>

      {/* Content */}
      <div className="flex-1 p-6 max-w-lg mx-auto w-full">
        {/* Prompt card */}
        <motion.div
          key={promptIndex}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex items-start justify-between mb-4">
            <p className="text-xs text-muted-foreground uppercase tracking-wider">
              Today's prompt
            </p>
            <button
              onClick={handleNewPrompt}
              className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              <RefreshCw className="w-3 h-3" />
              New prompt
            </button>
          </div>
          <h2 className="text-xl font-medium text-foreground">
            {currentPrompt}
          </h2>
        </motion.div>

        {/* Text area */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <textarea
            value={entry}
            onChange={(e) => setEntry(e.target.value)}
            placeholder="Start writing..."
            className="
              w-full h-64 p-4 rounded-xl
              bg-secondary/30 border border-border/30
              text-foreground placeholder:text-muted-foreground/50
              resize-none focus:outline-none focus:ring-2 focus:ring-primary/30
              transition-all
            "
          />
        </motion.div>

        {/* Save button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Button
            onClick={handleSave}
            disabled={!entry.trim() || isSaved}
            className="w-full"
            variant={isSaved ? 'calm' : 'hero'}
          >
            {isSaved ? 'Saved ✓' : 'Save Entry'}
          </Button>
        </motion.div>

        {/* Note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="text-center text-xs text-muted-foreground/60 mt-8"
        >
          Your thoughts are private and safe here.
        </motion.p>
      </div>
    </div>
  );
}
