import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Sparkles, Heart, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ChatMessage } from '@/components/chat/ChatMessage';
import { TypingIndicator } from '@/components/chat/TypingIndicator';
import { EmotionalInsight } from '@/components/chat/EmotionalInsight';
import {
  generateMockResponse,
  initialAIMessage,
  type MockAIResponse
} from '@/data/mockResponses';
import type { MoodType } from './onboarding/EmotionalBaseline';

/**
 * Chat Page
 * 
 * The main conversational interface where users interact with the AI companion.
 * Features:
 * - Message bubbles (user vs AI styling)
 * - Simulated AI typing delay
 * - Emotional insight panel
 * - Navigation to Health Space
 * 
 * MOCKED: All AI responses come from mockResponses.ts
 * In production, this would call an AI API (OpenAI, Anthropic, etc.)
 */

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: string;
}

interface ChatProps {
  userName?: string;
  initialMood?: MoodType;
  onOpenHealthSpace: () => void;
  onEndSession: (startDrift: number, endDrift: number) => void;
  onBack: () => void;
}

export function Chat({ userName, initialMood, onOpenHealthSpace, onEndSession, onBack }: ChatProps) {
  // State for messages
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isAITyping, setIsAITyping] = useState(false);

  // State for emotional insights (from mock AI responses)
  const [currentInsight, setCurrentInsight] = useState<MockAIResponse>(initialAIMessage);
  const [initialDrift] = useState(initialAIMessage.driftScore);

  // Ref for auto-scrolling
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Initialize with personalized AI greeting based on mood
  useEffect(() => {
    // Build personalized greeting based on user's initial mood
    let greetingText = initialAIMessage.reply;
    if (userName) {
      greetingText = `Hi ${userName}. ` + greetingText;
    }
    if (initialMood === 'lonely') {
      greetingText = userName
        ? `Hi ${userName}. I'm glad you reached out. Nights can feel long when you're feeling alone.`
        : "I'm glad you reached out. Nights can feel long when you're feeling alone.";
    } else if (initialMood === 'anxious') {
      greetingText = userName
        ? `Hi ${userName}. It's okay to feel anxious. Let's take this moment together.`
        : "It's okay to feel anxious. Let's take this moment together.";
    } else if (initialMood === 'overwhelmed') {
      greetingText = userName
        ? `Hi ${userName}. I hear you. When everything feels like too much, even small steps matter.`
        : "I hear you. When everything feels like too much, even small steps matter.";
    }

    const greeting: Message = {
      id: 'initial',
      content: greetingText,
      isUser: false,
      timestamp: new Date().toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
      }),
    };
    setMessages([greeting]);
  }, [userName, initialMood]);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isAITyping]);

  // Handle sending a message
  const handleSendMessage = async () => {
    if (!inputValue.trim() || isAITyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue.trim(),
      isUser: true,
      timestamp: new Date().toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: '2-digit',
      }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsAITyping(true);

    // Simulate AI "thinking" delay (1.5-3 seconds)
    // In production, this would be actual API response time
    const typingDelay = 1500 + Math.random() * 1500;

    setTimeout(() => {
      // Get mock AI response based on user input
      const aiResponse = generateMockResponse(userMessage.content);

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: aiResponse.reply,
        isUser: false,
        timestamp: new Date().toLocaleTimeString('en-US', {
          hour: 'numeric',
          minute: '2-digit',
        }),
      };

      setMessages((prev) => [...prev, aiMessage]);
      setCurrentInsight(aiResponse);
      setIsAITyping(false);
    }, typingDelay);
  };

  // Handle Enter key
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Main chat area */}
      <div className="flex-1 flex flex-col max-w-3xl mx-auto w-full">
        {/* Header */}
        <motion.header
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between p-4 border-b border-border/50"
        >
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={onBack}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Heart className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="font-semibold text-foreground">
                {userName ? `Chat with ${userName}` : 'Night Companion'}
              </h1>
              <p className="text-xs text-muted-foreground">Here with you</p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant="calm"
              size="sm"
              onClick={onOpenHealthSpace}
              className="gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">Health Space</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEndSession(initialDrift, currentInsight.driftScore)}
            >
              End Session
            </Button>
          </div>
        </motion.header>

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto p-4 scrollbar-calm">
          <AnimatePresence mode="popLayout">
            {messages.map((message) => (
              <ChatMessage
                key={message.id}
                content={message.content}
                isUser={message.isUser}
                timestamp={message.timestamp}
              />
            ))}
          </AnimatePresence>

          {/* Typing indicator */}
          <AnimatePresence>
            {isAITyping && <TypingIndicator />}
          </AnimatePresence>

          {/* Scroll anchor */}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 border-t border-border/50"
        >
          <div className="flex gap-3 items-center">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Share what's on your mind..."
              disabled={isAITyping}
              className="flex-1 h-12 px-4 rounded-xl bg-secondary border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all disabled:opacity-50"
            />
            <Button
              variant="default"
              size="icon"
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isAITyping}
              className="h-12 w-12 shrink-0"
            >
              <Send className="w-5 h-5" />
            </Button>
          </div>

          {/* Suggestion based on AI insight */}
          <AnimatePresence>
            {currentInsight.suggestion && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="mt-3 flex items-center gap-2"
              >
                <span className="text-xs text-muted-foreground">
                  Would a {currentInsight.suggestion} exercise help?
                </span>
                <Button
                  variant="link"
                  size="sm"
                  className="text-primary text-xs p-0 h-auto"
                  onClick={onOpenHealthSpace}
                >
                  Try it →
                </Button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Emotional insight panel (sidebar on large screens) */}
      <motion.aside
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.3 }}
        className="hidden lg:block w-72 p-4 border-l border-border/50"
      >
        <EmotionalInsight
          emotion={currentInsight.emotion}
          driftScore={currentInsight.driftScore}
          suggestion={currentInsight.suggestion}
        />

        {/* Mobile insight preview - shown inline on small screens */}
      </motion.aside>

      {/* Mobile emotional insight - collapsible at bottom */}
      <div className="lg:hidden p-4 border-t border-border/50">
        <details className="group">
          <summary className="flex items-center gap-2 cursor-pointer text-sm text-muted-foreground list-none">
            <Sparkles className="w-4 h-4" />
            <span>View emotional insight</span>
            <span className="ml-auto text-xs opacity-60 group-open:hidden">Tap to expand</span>
          </summary>
          <div className="mt-4">
            <EmotionalInsight
              emotion={currentInsight.emotion}
              driftScore={currentInsight.driftScore}
              suggestion={currentInsight.suggestion}
            />
          </div>
        </details>
      </div>
    </div>
  );
}
