import { motion } from 'framer-motion';

/**
 * ChatMessage Component
 * 
 * Renders individual chat bubbles for user and AI messages.
 * Uses different styling for each sender type.
 * 
 * In production, this would likely include:
 * - Message timestamps
 * - Read receipts
 * - Message reactions
 */

interface ChatMessageProps {
  content: string;
  isUser: boolean;
  timestamp?: string;
}

export function ChatMessage({ content, isUser, timestamp }: ChatMessageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}
    >
      <div
        className={`
          max-w-[80%] px-4 py-3 
          ${isUser 
            ? 'message-user ml-8' 
            : 'message-ai mr-8'
          }
        `}
      >
        {/* Message content */}
        <p className="text-sm sm:text-base leading-relaxed font-medium">
          {content}
        </p>
        
        {/* Optional timestamp */}
        {timestamp && (
          <span className="text-xs text-muted-foreground mt-1 block opacity-60">
            {timestamp}
          </span>
        )}
      </div>
    </motion.div>
  );
}
