import { motion, AnimatePresence } from 'framer-motion';
import { Wind, X } from 'lucide-react';

/**
 * Wellness Check-In Card
 * 
 * A gentle, optional interruption triggered by simulated smartwatch signals.
 * Appears on the dashboard when an unexpected physiological change is detected
 * while the user is resting.
 * 
 * CALMNESS SAFEGUARDS:
 * - No urgency or alarms
 * - No medical language or numbers
 * - User always has control (can dismiss)
 * - Max one check-in per day
 * - Non-blocking, subtle visual design
 * - No repeated alerts after dismissal
 */

interface WellnessCheckInProps {
    onTakeBreath: () => void;
    onDismiss: () => void;
}

export function WellnessCheckIn({ onTakeBreath, onDismiss }: WellnessCheckInProps) {
    return (
        <AnimatePresence>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="relative p-5 rounded-2xl bg-gradient-to-br from-accent/15 to-accent/5 border border-accent/30"
            >
                {/* Dismiss button - subtle, top-right */}
                <button
                    onClick={onDismiss}
                    className="absolute top-4 right-4 text-muted-foreground/40 hover:text-muted-foreground/70 transition-colors"
                    aria-label="Dismiss"
                >
                    <X className="w-4 h-4" />
                </button>

                {/* Content */}
                <div className="pr-8">
                    {/* Title - calm, non-alarming */}
                    <h3 className="text-base font-medium text-foreground mb-3">
                        A gentle check-in
                    </h3>

                    {/* Body - 2 lines max, no medical language */}
                    <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                        Your body showed a small change while you were resting.
                        <br />
                        Would you like to pause for a moment?
                    </p>

                    {/* Actions - exactly TWO */}
                    <div className="flex gap-3">
                        {/* Primary: Take a breath */}
                        <button
                            onClick={onTakeBreath}
                            className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-primary/20 hover:bg-primary/30 border border-primary/30 hover:border-primary/40 transition-all text-primary"
                        >
                            <Wind className="w-4 h-4" />
                            <span className="text-sm font-medium">Take a breath</span>
                        </button>

                        {/* Secondary: Not now */}
                        <button
                            onClick={onDismiss}
                            className="px-4 py-3 rounded-xl bg-secondary/20 hover:bg-secondary/30 border border-border/20 hover:border-border/30 transition-all text-muted-foreground hover:text-foreground text-sm"
                        >
                            Not now
                        </button>
                    </div>
                </div>
            </motion.div>
        </AnimatePresence>
    );
}
